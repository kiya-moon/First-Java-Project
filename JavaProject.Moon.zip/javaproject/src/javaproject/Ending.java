package javaproject;


public class Ending extends Thread {
	public void ending() {
		System.out.println("당신은 당신의 방에서 깨어납니다. 시계를 보니 새벽 4시 36분이네요. "
				+ "긴 꿈을 꿨던 것 같습니다...");
	}
}
